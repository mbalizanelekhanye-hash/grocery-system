using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
namespace GrocerySystem {
 public partial class FrmGroceryItems : Form {
  private DataGridView grid; private TextBox name,description,price,image; private CheckBox available; private PictureBox preview; private int id;
  public FrmGroceryItems() { Session.RequireAdmin(); InitializeComponent(); Shown+=(s,e)=>Ui.Run(LoadItems); }
  private void Build() {
   Ui.Form(this,"Grocery item maintenance",1180,850);
   Ui.Label(this,"Select an item to edit, or choose New item.",25,20,1000);
   grid=Ui.Grid(this,25,65,1110,260); grid.SelectionChanged+=(s,e)=>Ui.Run(SelectItem);
   Ui.Label(this,"Item name",25,355); name=Ui.Text(this,240,355,460); name.MaxLength=100;
   Ui.Label(this,"Description",25,405); description=Ui.Text(this,240,405,460); description.MaxLength=500;
   Ui.Label(this,"Price (R)",25,455); price=Ui.Text(this,240,455,200);
   available=Ui.Check(this,"Available for ordering",460,455);
   Ui.Label(this,"Image path or URL",25,510); image=Ui.Text(this,240,510,460); image.MaxLength=500;
   Ui.Button(this,"Browse image",730,510,Browse,170);
   preview=new PictureBox { Left=925,Top=355,Width=200,Height=180,SizeMode=PictureBoxSizeMode.Zoom,BorderStyle=BorderStyle.FixedSingle }; Controls.Add(preview);
   Ui.Label(this,"Preview uses local images.",915,550,220);
   Ui.Button(this,"New item",25,595,Clear);
   Ui.Button(this,"Save item",230,595,Save);
   Ui.Button(this,"Refresh",435,595,LoadItems);
   Ui.Button(this,"Close",640,595,()=>Close());
   Ui.Label(this,"Set availability off to retire an item. Historical orders retain their original price and name.",25,675,1100);
   FormClosed+=(s,e)=>{if(preview.Image!=null) preview.Image.Dispose();};
  }
  private void LoadItems() { Session.RequireAdmin(); grid.DataSource=Db.Items(false); }
  private void Clear() { id=0; name.Clear(); description.Clear(); price.Clear(); image.Clear(); available.Checked=true; ShowImage(); name.Focus(); }
  private void SelectItem() {
   if(grid.CurrentRow==null) return;
   id=Convert.ToInt32(Ui.Cell(grid,"ItemID")); name.Text=Ui.Cell(grid,"ItemName"); description.Text=Ui.Cell(grid,"Description"); price.Text=Ui.Cell(grid,"Price"); image.Text=Ui.Cell(grid,"ImagePath"); available.Checked=Convert.ToBoolean(grid.CurrentRow.Cells["IsAvailable"].Value); ShowImage();
  }
  private void Save() { Db.SaveItem(id,name.Text,description.Text,Rules.Price(price.Text),available.Checked,image.Text.Trim()); LoadItems(); Clear(); Ui.Info("Grocery item saved."); }
  private void Browse() { using(var d=new OpenFileDialog { Filter="Images|*.png;*.jpg;*.jpeg;*.bmp;*.gif" }) if(d.ShowDialog()==DialogResult.OK) {
   string dir=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Images"); Directory.CreateDirectory(dir);
   string relative=Path.Combine("Images",Guid.NewGuid().ToString("N")+Path.GetExtension(d.FileName));
   File.Copy(d.FileName,Path.Combine(AppDomain.CurrentDomain.BaseDirectory,relative)); image.Text=relative; ShowImage();
  } }
  private void ShowImage() {
   if(preview.Image!=null) {preview.Image.Dispose(); preview.Image=null;}
   string path=Path.IsPathRooted(image.Text) ? image.Text : Path.Combine(AppDomain.CurrentDomain.BaseDirectory,image.Text);
   if(!File.Exists(path)) return;
   using(var source=Image.FromFile(path)) preview.Image=new Bitmap(source);
  }
 }
}
