// Run only against a fresh, isolated demo database containing 02_DemoData.sql.
// These checks deliberately modify and restore demo records. Never point them at real data.
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
namespace GrocerySystem
{
    internal static class IntegrationTests
    {
        private static int count;
        private static void Assert(bool ok,string label) { if(!ok)throw new Exception("FAILED: "+label);count++;Console.WriteLine("PASS: "+label); }
        private static void Reject(Action action,string label) { try{action();}catch(InvalidOperationException){Assert(true,label);return;}throw new Exception("FAILED: "+label); }
        public static void Main()
        {
            Assert(Db.Login("Matron","matron","Matron@2026!"),"Seeded Matron login via configured provider");
            DateTime start=new DateTime(2026,9,4),end=new DateTime(2026,9,18);
            var trends=Db.Report(0,start,end);
            Assert(trends.Rows.Count==14 && trends.AsEnumerable().Sum(r=>Convert.ToDecimal(r["TotalValue"]))==260m,"MIS trends total and zero-item retention");
            var rates=Db.Report(1,start,end);Assert(Convert.ToDecimal(rates.Rows[1]["ParticipationPercent"])==33.33m,"MIS participation exact rounding");
            Assert(Db.Report(2,start,start).AsEnumerable().Sum(r=>Convert.ToDecimal(r["TotalValue"]))==119m,"Weekly consolidation matches captured history");
            int id=Db.SaveMember(0,"Integration Resident","T01","",true,"Test1234");Assert(id>3,"Add member persisted");
            Db.SaveMember(id,"Updated Integration Resident","T02","123",false,"");
            Assert(!Db.Login("Member",id.ToString(),"Test1234"),"Deactivated member cannot log in");
            Db.Login("Matron","matron","Matron@2026!");Db.SaveMember(id,"Updated Integration Resident","T02","123",true,"");
            Assert(Db.Login("Member",id.ToString(),"Test1234"),"Unchanged password retained during member update");
            Assert(Db.MyOrders().Rows.Count==0,"New member has no other resident's history");
            Reject(()=>Db.Report(0,start,end),"Member reporting denied at service boundary");
            DateTime friday=Rules.Friday(Rules.LocalNow);
            if(Rules.LocalNow<Rules.Cutoff(friday))
            {
                var lines=new List<CartLine>{new CartLine{ItemId=1,ItemName="Milk 1 litre",Quantity=2,UnitPrice=19.99m},new CartLine{ItemId=2,ItemName="Brown bread",Quantity=1,UnitPrice=18.50m}};
                Db.SaveOrder(friday,lines);Assert(Db.MyOrders().Rows.Count==1,"Save first weekly order");
                int order=Convert.ToInt32(Db.MyOrders().Rows[0]["OrderID"]);
                lines[0].Quantity=3;Db.SaveOrder(friday,lines);
                Assert(Db.MyOrders().Rows.Count==1 && Convert.ToInt32(Db.MyOrders().Rows[0]["OrderID"])==order,"Edit updates same weekly order");
                Assert(Db.LoadOrder(friday).Single(x=>x.ItemId==1).Quantity==3,"Edited quantity persisted");
                Db.Login("Matron","matron","Matron@2026!");Db.SaveItem(1,"Milk 1 litre","Fresh milk, 1 litre",100m,true,"");
                Db.Login("Member",id.ToString(),"Test1234");Db.SaveOrder(friday,lines);
                Assert(Db.LoadOrder(friday).Single(x=>x.ItemId==1).UnitPrice==19.99m,"Editing retains captured historical price");
                Db.Login("Matron","matron","Matron@2026!");Db.SaveItem(2,"Brown bread","Brown bread loaf",18.50m,false,"");
                Db.Login("Member",id.ToString(),"Test1234");Reject(()=>Db.SaveOrder(friday,lines),"Availability rechecked during save");
                Assert(Db.LoadOrder(friday).Count==2,"Failed save preserves existing lines atomically");
                lines.RemoveAt(1);Db.SaveOrder(friday,lines);Assert(Db.LoadOrder(friday).Count==1,"Remove saved order line");
                Assert(Db.MyDetails(1).Rows.Count==0,"Other resident order details cannot be read");
            }
            else Console.WriteLine("SKIP: current cycle is closed; no clock bypass used.");
            Db.Login("Matron","matron","Matron@2026!");
            string path=Path.Combine(Path.GetTempPath(),"GroceryIntegration_"+Guid.NewGuid().ToString("N")+".xml");
            try
            {
                Backup.Create(path);var data=Backup.Read(path);Assert(data.Tables.Count==5,"Backup XML created and revalidated");
                Db.SaveMember(id,"Changed after backup","X01","",true,"");Backup.Restore(data);
                Assert(!Session.IsAdmin,"Recovery clears authentication");
                Assert(Db.Login("Matron","matron","Matron@2026!"),"Recovered account logs in");
                Assert(Convert.ToString(Db.Members().AsEnumerable().Single(r=>Convert.ToInt32(r["MemberID"])==id)["FullName"])=="Updated Integration Resident","Recovery restores original member values");
                Assert(Db.Report(0,start,end).AsEnumerable().Sum(r=>Convert.ToDecimal(r["TotalValue"]))==260m,"Recovered MIS history matches original totals");
            }
            finally {if(File.Exists(path))File.Delete(path);}
            Session.Clear();Console.WriteLine(count+" integration checks passed.");
        }
    }
}
