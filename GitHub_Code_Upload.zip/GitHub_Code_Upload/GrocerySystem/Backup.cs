using System;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml;

namespace GrocerySystem
{
    internal static class Backup
    {
        private static readonly string[] Tables = { "Admins", "Members", "grocery_items", "Orders", "OrderItems" };
        private static readonly string[] Columns = {
            "AdminID,Username,PasswordHash,IsActive", "MemberID,FullName,RoomNumber,Phone,IsActive,PasswordHash",
            "ItemID,ItemName,Description,Price,IsAvailable,ImagePath", "OrderID,MemberID,WeekFriday,CreatedAt,UpdatedAt",
            "OrderID,ItemID,ItemNameSnapshot,Quantity,UnitPrice" };
        public static void Create(string path)
        {
            Session.RequireAdmin(); var data = new DataSet("GroceryBackupV1");
            // A single repeatable-read transaction captures all five related tables consistently.
            using (var con = Db.Open()) using (var tx = con.BeginTransaction(IsolationLevel.RepeatableRead))
            {
                for (int i=0;i<Tables.Length;i++)
                using (var cmd=Db.Command(con,tx,"SELECT "+Columns[i]+" FROM `"+Tables[i]+"`"))
                using (var adapter=new MySql.Data.MySqlClient.MySqlDataAdapter(cmd))
                { var table=new DataTable(Tables[i]); adapter.Fill(table); data.Tables.Add(table); }
                tx.Commit();
            }
            Validate(data);
            string pending=path+".pending";
            try { data.WriteXml(pending,XmlWriteMode.WriteSchema); File.Copy(pending,path,true); }
            finally { if(File.Exists(pending))File.Delete(pending); }
        }
        public static DataSet Read(string path)
        {
            if(new FileInfo(path).Length>100*1024*1024) throw new InvalidOperationException("This backup exceeds the supported 100 MB size.");
            var data=new DataSet();
            using(var reader=XmlReader.Create(path,new XmlReaderSettings { DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null,MaxCharactersInDocument=100*1024*1024 })) data.ReadXml(reader,XmlReadMode.ReadSchema);
            Validate(data); return data;
        }
        public static void Validate(DataSet data)
        {
            if(data.DataSetName!="GroceryBackupV1" || data.Tables.Count!=5) throw new InvalidOperationException("Select a valid Grocery System V1 backup.");
            for(int i=0;i<Tables.Length;i++)
            {
                var t=data.Tables[Tables[i]];
                if(t==null || t.Columns.Count!=Columns[i].Split(',').Length || Columns[i].Split(',').Any(c=>!t.Columns.Contains(c))) throw new InvalidOperationException("Backup table or column is missing: "+Tables[i]);
                foreach(DataRow r in t.Rows) if(r.ItemArray.Any(v=>v==DBNull.Value)) throw new InvalidOperationException("Backup contains an incomplete row in "+Tables[i]);
            }
            foreach(string table in new[]{"Admins","Members","grocery_items","Orders"})
            {
                string key=table=="Admins"?"AdminID":table=="Members"?"MemberID":table=="Orders"?"OrderID":"ItemID";
                var ids=data.Tables[table].AsEnumerable().Select(r=>Convert.ToInt32(r[key])).ToList();
                if(ids.Any(x=>x<=0)||ids.Distinct().Count()!=ids.Count) throw new InvalidOperationException("Invalid or duplicate primary key in "+table);
            }
            if(!data.Tables["Admins"].AsEnumerable().Any(r=>Convert.ToBoolean(r["IsActive"]))) throw new InvalidOperationException("The backup must contain an active Matron account.");
            var members=data.Tables["Members"].AsEnumerable().Select(r=>Convert.ToInt32(r["MemberID"])).ToList();
            var items=data.Tables["grocery_items"].AsEnumerable().Select(r=>Convert.ToInt32(r["ItemID"])).ToList();
            var orders=data.Tables["Orders"].AsEnumerable().ToList();
            if(orders.GroupBy(r=>Convert.ToInt32(r["MemberID"])+"/"+Convert.ToDateTime(r["WeekFriday"]).ToString("yyyy-MM-dd")).Any(g=>g.Count()>1)) throw new InvalidOperationException("Duplicate weekly order in backup.");
            foreach(var order in orders)
            {
                DateTime friday=Convert.ToDateTime(order["WeekFriday"]);
                if(!members.Contains(Convert.ToInt32(order["MemberID"]))||friday.DayOfWeek!=DayOfWeek.Friday||friday.TimeOfDay!=TimeSpan.Zero) throw new InvalidOperationException("Invalid member or Friday cycle in backup.");
                var lines=data.Tables["OrderItems"].AsEnumerable().Where(r=>Convert.ToInt32(r["OrderID"])==Convert.ToInt32(order["OrderID"])).ToList();
                if(lines.Count<1||lines.Count>12||lines.Select(r=>Convert.ToInt32(r["ItemID"])).Distinct().Count()!=lines.Count) throw new InvalidOperationException("Invalid order item count in backup.");
            }
            foreach(DataRow line in data.Tables["OrderItems"].Rows)
            {
                int q=Convert.ToInt32(line["Quantity"]); decimal p=Convert.ToDecimal(line["UnitPrice"]);
                if(!items.Contains(Convert.ToInt32(line["ItemID"]))||!orders.Any(o=>Convert.ToInt32(o["OrderID"])==Convert.ToInt32(line["OrderID"]))||q<1||q>999||p<=0||p>99999999.99m||decimal.Round(p,2)!=p)
                    throw new InvalidOperationException("Invalid order line in backup.");
            }
        }
        public static void Restore(DataSet data)
        {
            Session.RequireAdmin(); Validate(data);
            using(var con=Db.Open()) using(var tx=con.BeginTransaction(IsolationLevel.Serializable))
            {
                // Keep foreign keys enabled; delete children first, insert parents first.
                foreach(var table in Tables.Reverse()) using(var cmd=Db.Command(con,tx,"DELETE FROM `"+table+"`")) cmd.ExecuteNonQuery();
                for(int i=0;i<Tables.Length;i++)
                {
                    string[] columns=Columns[i].Split(',');
                    string sql="INSERT INTO `"+Tables[i]+"` ("+Columns[i]+") VALUES ("+string.Join(",",columns.Select((c,n)=>"@p"+n))+ ")";
                    foreach(DataRow row in data.Tables[Tables[i]].Rows)
                    {
                        var args=columns.SelectMany((c,n)=>new object[]{"@p"+n,row[c]}).ToArray();
                        using(var cmd=Db.Command(con,tx,sql,args)) cmd.ExecuteNonQuery();
                    }
                    // Verify restored values, not only record counts, before committing.
                    using(var cmd=Db.Command(con,tx,"SELECT "+Columns[i]+" FROM `"+Tables[i]+"`"))
                    using(var adapter=new MySql.Data.MySqlClient.MySqlDataAdapter(cmd))
                    {
                        var restored=new DataTable(); adapter.Fill(restored);
                        Func<DataRow,string> encode=r=>string.Join("|",columns.Select(c=>Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(Convert.ToString(r[c],CultureInfo.InvariantCulture)))));
                        var expected=data.Tables[Tables[i]].AsEnumerable().Select(encode).OrderBy(x=>x).ToArray();
                        var actual=restored.AsEnumerable().Select(encode).OrderBy(x=>x).ToArray();
                        if(!expected.SequenceEqual(actual)) throw new InvalidOperationException("Recovery verification failed for "+Tables[i]+". No changes have been committed.");
                    }
                }
                tx.Commit();
            }
            Session.Clear();
        }
    }

    internal sealed class BackupForm : Form
    {
        private Label result;
        public BackupForm()
        {
            Session.RequireAdmin(); Ui.Form(this,"Database backup and recovery",1000,640);
            var explanation=Ui.Label(this,"Manual backup saves all five database tables, including orders, captured prices and account password hashes. Make a backup before changes and at least weekly after Friday processing. Keep a protected copy on a separate drive. See README.md for restoring image files.",25,25,925); explanation.Height=140;
            Ui.Button(this,"Create backup",25,190,Create,280);
            Ui.Button(this,"Validate backup",345,190,ValidateFile,280);
            Ui.Button(this,"Restore backup",665,190,Restore,280);
            result=Ui.Label(this,"No backup action performed in this session.",25,280,925); result.Height=170;
            Ui.Button(this,"Close",25,490,()=>Close());
            Ui.Label(this,"Restore replaces this database's application data. All other users must be logged out first.",25,550,925);
        }
        private void Create()
        {
            using(var d=new SaveFileDialog { Filter="Grocery backup (*.xml)|*.xml",FileName="GroceryBackup_"+Rules.LocalNow.ToString("yyyyMMdd_HHmmss")+".xml" })
            if(d.ShowDialog()==DialogResult.OK) { Backup.Create(d.FileName); var data=Backup.Read(d.FileName); result.Text="Backup saved and validated: "+d.FileName+Environment.NewLine+Counts(data); }
        }
        private void ValidateFile()
        { using(var d=Picker()) if(d.ShowDialog()==DialogResult.OK) { var data=Backup.Read(d.FileName); result.Text="Valid backup: "+d.FileName+Environment.NewLine+Counts(data); } }
        private void Restore()
        {
            using(var d=Picker()) if(d.ShowDialog()==DialogResult.OK)
            {
                var data=Backup.Read(d.FileName);
                if(MessageBox.Show("Replace the current database data with this backup?\n"+Counts(data)+"\nMake a fresh backup first and ensure other users are logged out.","Confirm recovery",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes) return;
                string safety=Path.Combine(Path.GetDirectoryName(d.FileName),"BeforeRecovery_"+Rules.LocalNow.ToString("yyyyMMdd_HHmmss")+"_"+Guid.NewGuid().ToString("N")+".xml");
                Backup.Create(safety); Backup.Restore(data);
                Ui.Info("Recovery completed. Every restored row was verified. Safety backup: "+safety+"\nPlease log in again using the recovered accounts."); Close();
            }
        }
        private static OpenFileDialog Picker() { return new OpenFileDialog { Filter="Grocery backup (*.xml)|*.xml" }; }
        private static string Counts(DataSet data) { return string.Join(", ",data.Tables.Cast<DataTable>().Select(t=>t.TableName+": "+t.Rows.Count)); }
    }
}
