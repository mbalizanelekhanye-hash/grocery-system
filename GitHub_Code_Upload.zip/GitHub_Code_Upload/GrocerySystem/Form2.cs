using System;
using System.Windows.Forms;
namespace GrocerySystem {
 public partial class Login : Form {
  private TextBox username,password; private ComboBox role;
  public Login() { InitializeComponent(); }
  private void Build() {
   Ui.Form(this,"Grocery System - Login",720,570);
   Ui.Label(this,"Weekly groceries for our residents",40,35,630);
   Ui.Label(this,"Role",40,105); role=new ComboBox { Left=280,Top=105,Width=320,DropDownStyle=ComboBoxStyle.DropDownList };
   role.Items.AddRange(new object[]{"Member","Matron"}); role.SelectedIndex=0; Controls.Add(role);
   Ui.Label(this,"Member ID / username",40,165); username=Ui.Text(this,280,165,320); username.MaxLength=100;
   Ui.Label(this,"Password",40,225); password=Ui.Text(this,280,225,320,true); password.MaxLength=128;
   AcceptButton=Ui.Button(this,"Log in",280,285,LogIn,320);
   Ui.Button(this,"About",40,285,()=>{using(var f=new FrmAbout()) f.ShowDialog(this);},180);
   Ui.Label(this,"Members use their member ID. The Matron uses a username.",40,375,630);
  }
  private void LogIn() {
   string user=Rules.Required(username.Text,"Member ID / username",100);
   if(password.Text.Length==0) throw new InvalidOperationException("Enter your password.");
   if(!Db.Login(role.Text,user,password.Text)) { password.Clear(); throw new InvalidOperationException("Login failed. Check your role, ID and password, or ask the Matron whether your account is active."); }
   password.Clear(); Hide();
   try { using(Form next=Session.IsAdmin ? (Form)new FrmDashboard() : new MemberOrderForm()) next.ShowDialog(); }
   finally { Session.Clear(); username.Clear(); Show(); username.Focus(); }
  }
 }
}
