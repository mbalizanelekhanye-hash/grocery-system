namespace GrocerySystem { partial class MemberOrderForm { private void InitializeComponent() { Build(); } } }
