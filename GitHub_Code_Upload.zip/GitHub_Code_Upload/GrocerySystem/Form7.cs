using System;
using System.Windows.Forms;
namespace GrocerySystem {
 public partial class MemberOrderForm : Form {
  public MemberOrderForm() { Session.RequireMember(); InitializeComponent(); }
  private void Build() {
   Ui.Form(this,"Member dashboard",850,530);
   Ui.Label(this,"Welcome, "+Session.Name,35,35,760);
   Ui.Label(this,"Your member ID: "+Session.MemberId,35,90,760);
   Ui.Button(this,"Place / edit weekly order",35,160,()=>{ using(var f=new FrmOderlist()) f.ShowDialog(this); },740);
   Ui.Button(this,"My order history",35,235,()=>{ using(var f=new FrmViewOrders()) f.ShowDialog(this); },740);
   Ui.Button(this,"About",35,325,()=>{using(var f=new FrmAbout()) f.ShowDialog(this);},350);
   Ui.Button(this,"Log out",425,325,()=>Close(),350);
  }
 }
}
