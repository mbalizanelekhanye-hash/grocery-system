using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using MySql.Data.MySqlClient;

namespace GrocerySystem
{
    // A session is established only after credentials have been checked in the database.
    internal static class Session
    {
        public static bool IsAdmin { get; private set; }
        public static int MemberId { get; private set; }
        public static string Name { get; private set; }
        public static void Admin(string name) { Clear(); IsAdmin = true; Name = name; }
        public static void Member(int id, string name) { Clear(); MemberId = id; Name = name; }
        public static void Clear() { IsAdmin = false; MemberId = 0; Name = null; }
        public static void RequireAdmin() { if (!IsAdmin) throw new InvalidOperationException("Please log in as the Matron to use this feature."); }
        public static void RequireMember() { if (IsAdmin || MemberId <= 0) throw new InvalidOperationException("Please log in as a member to place or view your orders."); }
    }

    internal static class Passwords
    {
        public static string Hash(string password)
        {
            byte[] salt = new byte[16];
            using (var random = RandomNumberGenerator.Create()) random.GetBytes(salt);
            using (var derive = new Rfc2898DeriveBytes(password, salt, 100000, HashAlgorithmName.SHA256))
                return "pbkdf2$100000$" + Convert.ToBase64String(salt) + "$" + Convert.ToBase64String(derive.GetBytes(32));
        }
        public static bool Verify(string password, string stored)
        {
            try
            {
                string[] parts = stored.Split('$');
                if (parts.Length != 4 || parts[0] != "pbkdf2") return false;
                int iterations;
                if (!int.TryParse(parts[1], out iterations) || iterations < 100000 || iterations > 1000000) return false;
                byte[] expected = Convert.FromBase64String(parts[3]);
                if (expected.Length != 32) return false;
                using (var derive = new Rfc2898DeriveBytes(password, Convert.FromBase64String(parts[2]), iterations, HashAlgorithmName.SHA256))
                {
                    byte[] actual = derive.GetBytes(32); int diff = 0;
                    for (int i = 0; i < actual.Length; i++) diff |= actual[i] ^ expected[i];
                    return diff == 0;
                }
            }
            catch (FormatException) { return false; }
            catch (ArgumentException) { return false; }
        }
    }

    internal static class Rules
    {
        public static DateTime LocalNow
        {
            get
            {
                TimeZoneInfo zone;
                try { zone = TimeZoneInfo.FindSystemTimeZoneById("South Africa Standard Time"); }
                catch (TimeZoneNotFoundException) { zone = TimeZoneInfo.FindSystemTimeZoneById("Africa/Johannesburg"); }
                return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, zone);
            }
        }
        public static DateTime Friday(DateTime now)
        { return now.Date.AddDays(((int)DayOfWeek.Friday - (int)now.DayOfWeek + 7) % 7); }
        public static DateTime Cutoff(DateTime friday)
        {
            int hour;
            if (!int.TryParse(ConfigurationManager.AppSettings["ThursdayCutoffHour"], out hour)) hour = 20;
            if (hour < 0 || hour > 23) throw new InvalidOperationException("ThursdayCutoffHour must be between 0 and 23.");
            return friday.Date.AddDays(-1).AddHours(hour);
        }
        public static void CheckWindow(DateTime friday, DateTime now)
        {
            if (friday.Date != Friday(now) || friday.DayOfWeek != DayOfWeek.Friday || now >= Cutoff(friday))
                throw new InvalidOperationException("Ordering for this Friday is closed. Orders may be saved until Thursday " + Cutoff(friday).ToString("HH:mm") + " (South African time). The next cycle opens on Saturday.");
        }
        public static decimal Price(string value)
        {
            decimal result;
            if (!decimal.TryParse(value, NumberStyles.Number, CultureInfo.CurrentCulture, out result) || result <= 0 || result > 99999999.99m || decimal.Round(result, 2) != result)
                throw new InvalidOperationException("Enter a positive price with no more than two decimal places.");
            return result;
        }
        public static string Required(string value, string label, int max)
        {
            value = value.Trim();
            if (value.Length == 0 || value.Length > max) throw new InvalidOperationException(label + " is required (maximum " + max + " characters).");
            return value;
        }
        public static void CheckCart(IEnumerable<CartLine> lines)
        {
            var cart = lines.ToList();
            if (cart.Count == 0 || cart.Count > 12) throw new InvalidOperationException("Choose between 1 and 12 different grocery items.");
            if (cart.Select(x => x.ItemId).Distinct().Count() != cart.Count) throw new InvalidOperationException("An item can appear only once in the order.");
            if (cart.Any(x => x.Quantity < 1 || x.Quantity > 999)) throw new InvalidOperationException("Each quantity must be a whole number from 1 to 999.");
        }
    }

    internal sealed class CartLine
    {
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal LineTotal { get { return Quantity * UnitPrice; } }
    }

    internal static class Db
    {
        public static MySqlConnection Open()
        {
            var setting = ConfigurationManager.ConnectionStrings["conn"];
            if (setting == null) throw new InvalidOperationException("The conn connection string is missing from App.config.");
            var con = new MySqlConnection(setting.ConnectionString);
            try { con.Open(); return con; } catch { con.Dispose(); throw; }
        }
        public static MySqlCommand Command(MySqlConnection con, MySqlTransaction tx, string sql, params object[] args)
        {
            var cmd = new MySqlCommand(sql, con, tx);
            for (int i = 0; i < args.Length; i += 2) cmd.Parameters.AddWithValue((string)args[i], args[i + 1] ?? DBNull.Value);
            return cmd;
        }
        public static DataTable Table(string sql, params object[] args)
        {
            using (var con = Open()) using (var cmd = Command(con, null, sql, args)) using (var adapter = new MySqlDataAdapter(cmd))
            { var dt = new DataTable(); adapter.Fill(dt); return dt; }
        }
        public static int Execute(string sql, params object[] args)
        { using (var con = Open()) using (var cmd = Command(con, null, sql, args)) return cmd.ExecuteNonQuery(); }
        public static bool Login(string role, string username, string password)
        {
            Session.Clear();
            DataTable dt;
            if (role == "Matron") dt = Table("SELECT Username,PasswordHash FROM Admins WHERE Username=@u AND IsActive=1", "@u", username);
            else
            {
                int id;
                if (!int.TryParse(username, out id) || id <= 0) return false;
                dt = Table("SELECT MemberID,FullName,PasswordHash FROM Members WHERE MemberID=@u AND IsActive=1", "@u", id);
            }
            if (dt.Rows.Count != 1 || !Passwords.Verify(password, Convert.ToString(dt.Rows[0]["PasswordHash"]))) return false;
            if (role == "Matron") Session.Admin(username);
            else Session.Member(Convert.ToInt32(dt.Rows[0]["MemberID"]), Convert.ToString(dt.Rows[0]["FullName"]));
            return true;
        }
        public static void ChangeAdminPassword(string current, string next)
        {
            Session.RequireAdmin();
            if(next.Length<8 || next.Length>128) throw new InvalidOperationException("Use a password containing 8 to 128 characters.");
            var dt=Table("SELECT PasswordHash FROM Admins WHERE Username=@u AND IsActive=1","@u",Session.Name);
            if(dt.Rows.Count!=1 || !Passwords.Verify(current,Convert.ToString(dt.Rows[0][0]))) throw new InvalidOperationException("The current Matron password is incorrect.");
            Execute("UPDATE Admins SET PasswordHash=@h WHERE Username=@u AND IsActive=1","@h",Passwords.Hash(next),"@u",Session.Name);
        }
        public static DataTable Members() { Session.RequireAdmin(); return Table("SELECT MemberID,FullName,RoomNumber,Phone,IsActive FROM Members ORDER BY FullName"); }
        public static DataTable Items(bool availableOnly)
        {
            if (availableOnly) Session.RequireMember(); else Session.RequireAdmin();
            return Table("SELECT ItemID,ItemName,Description,Price,IsAvailable,ImagePath FROM grocery_items" + (availableOnly ? " WHERE IsAvailable=1" : "") + " ORDER BY ItemName");
        }
        public static int SaveMember(int id, string name, string room, string phone, bool active, string password)
        {
            Session.RequireAdmin(); name = Rules.Required(name, "Member name", 100); room = Rules.Required(room, "Room number", 20);
            if (phone.Length > 30) throw new InvalidOperationException("Phone number is too long.");
            if (id == 0 || password.Length > 0)
            { if (password.Length < 4 || password.Length > 128) throw new InvalidOperationException("Member password must contain 4 to 128 characters."); }
            if (id == 0)
            {
                using (var con = Open()) using (var cmd = Command(con, null, "INSERT INTO Members(FullName,RoomNumber,Phone,IsActive,PasswordHash) VALUES(@n,@r,@p,@a,@h)", "@n", name,"@r",room,"@p",phone,"@a",active,"@h",Passwords.Hash(password)))
                { cmd.ExecuteNonQuery(); return checked((int)cmd.LastInsertedId); }
            }
            int count = Execute("UPDATE Members SET FullName=@n,RoomNumber=@r,Phone=@p,IsActive=@a" + (password.Length > 0 ? ",PasswordHash=@h" : "") + " WHERE MemberID=@id", "@n",name,"@r",room,"@p",phone,"@a",active,"@h",password.Length > 0 ? Passwords.Hash(password) : "", "@id",id);
            if (count == 0) throw new InvalidOperationException("This member no longer exists. Refresh the list.");
            return id;
        }
        public static void SaveItem(int id, string name, string description, decimal price, bool available, string image)
        {
            Session.RequireAdmin(); name = Rules.Required(name, "Item name", 100); description = Rules.Required(description, "Description", 500);
            if (price <= 0 || price > 99999999.99m || decimal.Round(price, 2) != price) throw new InvalidOperationException("Price must be positive with no more than two decimal places.");
            if (image.Length > 500) throw new InvalidOperationException("Image path is too long.");
            if (id == 0) Execute("INSERT INTO grocery_items(ItemName,Description,Price,IsAvailable,ImagePath) VALUES(@n,@d,@p,@a,@i)","@n",name,"@d",description,"@p",price,"@a",available,"@i",image);
            else if (Execute("UPDATE grocery_items SET ItemName=@n,Description=@d,Price=@p,IsAvailable=@a,ImagePath=@i WHERE ItemID=@id","@n",name,"@d",description,"@p",price,"@a",available,"@i",image,"@id",id) == 0)
                throw new InvalidOperationException("This item no longer exists. Refresh the list.");
        }
        public static List<CartLine> LoadOrder(DateTime friday)
        {
            Session.RequireMember();
            return Table("SELECT d.ItemID,d.ItemNameSnapshot,d.Quantity,d.UnitPrice FROM Orders o JOIN OrderItems d ON d.OrderID=o.OrderID WHERE o.MemberID=@m AND o.WeekFriday=@w ORDER BY d.ItemNameSnapshot","@m",Session.MemberId,"@w",friday.Date)
                .AsEnumerable().Select(r => new CartLine { ItemId=Convert.ToInt32(r["ItemID"]),ItemName=Convert.ToString(r["ItemNameSnapshot"]),Quantity=Convert.ToInt32(r["Quantity"]),UnitPrice=Convert.ToDecimal(r["UnitPrice"]) }).ToList();
        }
        // Member lock + unique index prevent two concurrent submissions creating duplicate orders.
        // All detail changes are atomic; existing lines retain their captured price and name.
        public static long SaveOrder(DateTime friday, List<CartLine> cart)
        {
            Session.RequireMember(); Rules.CheckCart(cart);
            using (var con = Open()) using (var tx = con.BeginTransaction(IsolationLevel.Serializable))
            {
                using (var cmd = Command(con,tx,"SELECT IsActive FROM Members WHERE MemberID=@m FOR UPDATE","@m",Session.MemberId))
                    if (Convert.ToInt32(cmd.ExecuteScalar() ?? 0) != 1) throw new InvalidOperationException("This member has been deactivated.");
                long orderId = 0;
                using (var cmd = Command(con,tx,"SELECT OrderID FROM Orders WHERE MemberID=@m AND WeekFriday=@w FOR UPDATE","@m",Session.MemberId,"@w",friday.Date))
                    orderId = Convert.ToInt64(cmd.ExecuteScalar() ?? 0);
                var old = new Dictionary<int, CartLine>();
                if (orderId > 0)
                    using (var cmd = Command(con,tx,"SELECT ItemID,UnitPrice,ItemNameSnapshot FROM OrderItems WHERE OrderID=@id","@id",orderId))
                    using (var reader = cmd.ExecuteReader()) while (reader.Read()) old.Add(reader.GetInt32(0), new CartLine { UnitPrice=reader.GetDecimal(1),ItemName=reader.GetString(2) });
                var saved = new List<CartLine>();
                foreach (var line in cart.OrderBy(x => x.ItemId))
                {
                    using (var cmd = Command(con,tx,"SELECT ItemName,Price,IsAvailable FROM grocery_items WHERE ItemID=@id FOR UPDATE","@id",line.ItemId))
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read() || !reader.GetBoolean(2)) throw new InvalidOperationException(line.ItemName + " is no longer available. Remove it from your basket.");
                        decimal price = old.ContainsKey(line.ItemId) ? old[line.ItemId].UnitPrice : reader.GetDecimal(1);
                        if (!old.ContainsKey(line.ItemId) && price != line.UnitPrice) throw new InvalidOperationException("The price of " + line.ItemName + " has changed. Refresh the catalogue, remove the item and add it again to review its price.");
                        saved.Add(new CartLine { ItemId=line.ItemId,Quantity=line.Quantity,UnitPrice=price,ItemName=old.ContainsKey(line.ItemId) ? old[line.ItemId].ItemName : reader.GetString(0) });
                    }
                }
                // Check as close to writing as possible, after acquiring database locks.
                DateTime now = Rules.LocalNow; Rules.CheckWindow(friday, now);
                if (orderId == 0)
                {
                    using (var cmd = Command(con,tx,"INSERT INTO Orders(MemberID,WeekFriday,CreatedAt,UpdatedAt) VALUES(@m,@w,@n,@n)","@m",Session.MemberId,"@w",friday.Date,"@n",now))
                    { cmd.ExecuteNonQuery(); orderId = cmd.LastInsertedId; }
                }
                else
                {
                    using (var cmd = Command(con,tx,"UPDATE Orders SET UpdatedAt=@n WHERE OrderID=@id","@n",now,"@id",orderId)) cmd.ExecuteNonQuery();
                    using (var cmd = Command(con,tx,"DELETE FROM OrderItems WHERE OrderID=@id","@id",orderId)) cmd.ExecuteNonQuery();
                }
                foreach (var line in saved)
                    using (var cmd = Command(con,tx,"INSERT INTO OrderItems(OrderID,ItemID,ItemNameSnapshot,Quantity,UnitPrice) VALUES(@o,@i,@n,@q,@p)","@o",orderId,"@i",line.ItemId,"@n",line.ItemName,"@q",line.Quantity,"@p",line.UnitPrice)) cmd.ExecuteNonQuery();
                Rules.CheckWindow(friday, Rules.LocalNow);
                tx.Commit();
                return orderId;
            }
        }
        public static DataTable MyOrders()
        {
            Session.RequireMember(); return Table("SELECT o.OrderID,o.WeekFriday,o.CreatedAt,o.UpdatedAt,COUNT(d.ItemID) AS DifferentItems,SUM(d.Quantity*d.UnitPrice) AS Total FROM Orders o JOIN OrderItems d ON d.OrderID=o.OrderID WHERE o.MemberID=@m GROUP BY o.OrderID,o.WeekFriday,o.CreatedAt,o.UpdatedAt ORDER BY o.WeekFriday DESC","@m",Session.MemberId);
        }
        public static DataTable MyDetails(int orderId)
        {
            Session.RequireMember(); return Table("SELECT d.ItemNameSnapshot AS Item,d.Quantity,d.UnitPrice,d.Quantity*d.UnitPrice AS LineTotal FROM Orders o JOIN OrderItems d ON d.OrderID=o.OrderID WHERE o.OrderID=@id AND o.MemberID=@m ORDER BY d.ItemNameSnapshot","@id",orderId,"@m",Session.MemberId);
        }
        public static int Fridays(DateTime start, DateTime end)
        { DateTime first = Rules.Friday(start.Date); return first > end.Date ? 0 : (end.Date - first).Days / 7 + 1; }
        public static DataTable Report(int type, DateTime start, DateTime end)
        {
            Session.RequireAdmin(); start=start.Date; end=end.Date;
            if (type != 2 && end < start) throw new InvalidOperationException("The end date must be on or after the start date.");
            if (type == 0)
                return Table("SELECT i.ItemID,i.ItemName,COALESCE(a.Quantity,0) AS TotalQuantity,COALESCE(a.OrderCount,0) AS WeeklyOrders,COALESCE(a.Spend,0) AS TotalValue FROM grocery_items i LEFT JOIN (SELECT d.ItemID,SUM(d.Quantity) Quantity,COUNT(DISTINCT o.OrderID) OrderCount,SUM(d.Quantity*d.UnitPrice) Spend FROM Orders o JOIN OrderItems d ON d.OrderID=o.OrderID WHERE o.WeekFriday BETWEEN @s AND @e GROUP BY d.ItemID) a ON a.ItemID=i.ItemID ORDER BY TotalQuantity DESC,i.ItemName","@s",start,"@e",end);
            if (type == 1)
            {
                int weeks = Fridays(start,end);
                return Table("SELECT m.MemberID,m.FullName,m.IsActive,COUNT(o.OrderID) AS WeeksOrdered,@weeks AS PossibleWeeks,CASE WHEN @weeks=0 THEN 0 ELSE ROUND(COUNT(o.OrderID)*100.0/@weeks,2) END AS ParticipationPercent FROM Members m LEFT JOIN Orders o ON o.MemberID=m.MemberID AND o.WeekFriday BETWEEN @s AND @e GROUP BY m.MemberID,m.FullName,m.IsActive ORDER BY WeeksOrdered DESC,m.FullName","@s",start,"@e",end,"@weeks",weeks);
            }
            if (type == 2)
            {
                if (start.DayOfWeek != DayOfWeek.Friday) throw new InvalidOperationException("Select a Friday as the start date for the weekly purchasing list.");
                return Table("SELECT d.ItemID,MIN(d.ItemNameSnapshot) AS Item,SUM(d.Quantity) AS Quantity,SUM(d.Quantity*d.UnitPrice) AS TotalValue FROM Orders o JOIN OrderItems d ON d.OrderID=o.OrderID WHERE o.WeekFriday=@s GROUP BY d.ItemID ORDER BY Item","@s",start);
            }
            if (type == 4)
                return Table(@"SELECT o.WeekFriday,i.ItemID,i.ItemName,
                    SUM(d.Quantity) AS TotalQuantity,COUNT(DISTINCT o.OrderID) AS WeeklyOrders,
                    SUM(d.Quantity*d.UnitPrice) AS TotalValue
                    FROM Orders o JOIN OrderItems d ON d.OrderID=o.OrderID
                    JOIN grocery_items i ON i.ItemID=d.ItemID
                    WHERE o.WeekFriday BETWEEN @s AND @e
                    GROUP BY o.WeekFriday,i.ItemID,i.ItemName
                    ORDER BY o.WeekFriday,TotalQuantity DESC,i.ItemName", "@s", start, "@e", end);
            return Table("SELECT o.OrderID,o.WeekFriday,m.MemberID,m.FullName,d.ItemNameSnapshot AS Item,d.Quantity,d.UnitPrice,d.Quantity*d.UnitPrice AS LineTotal FROM Orders o JOIN Members m ON m.MemberID=o.MemberID JOIN OrderItems d ON d.OrderID=o.OrderID WHERE o.WeekFriday BETWEEN @s AND @e ORDER BY o.WeekFriday,m.FullName,o.OrderID,d.ItemNameSnapshot","@s",start,"@e",end);
        }
    }
}
