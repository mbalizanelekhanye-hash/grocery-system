namespace GrocerySystem { partial class FrmViewOrders { private void InitializeComponent() { Build(); } } }
