namespace GrocerySystem { partial class FrmGroceryItems { private void InitializeComponent() { Build(); } } }
