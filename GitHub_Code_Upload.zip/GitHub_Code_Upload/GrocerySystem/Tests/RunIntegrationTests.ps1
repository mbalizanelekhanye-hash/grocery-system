param(
    [Parameter(Mandatory=$true)][string]$ConnectionString,
    [switch]$ConfirmDisposableDemoDatabase,
    [ValidateRange(0,23)][int]$CutoffHour = 20
)
$ErrorActionPreference = 'Stop'
if (!$ConfirmDisposableDemoDatabase) { throw 'These tests modify data. Supply -ConfirmDisposableDemoDatabase only for a fresh isolated database with the supplied schema and demo data.' }
$project = Split-Path $PSScriptRoot -Parent
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path $compiler)) { $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
if (!(Test-Path $compiler)) { throw 'Install .NET Framework 4.7.2 or later first.' }
$output = Join-Path $env:TEMP ('GroceryIntegrationTests_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $output | Out-Null
try {
    $mysql = Join-Path $project 'packages\MySql.Data.26.7.0\lib\net462\MySql.Data.dll'
    & $compiler /nologo /target:exe ("/out:" + (Join-Path $output 'IntegrationTests.exe')) /r:System.Data.dll /r:System.Data.DataSetExtensions.dll /r:System.Core.dll /r:System.Configuration.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll ("/r:" + $mysql) (Join-Path $project 'Core.cs') (Join-Path $project 'Backup.cs') (Join-Path $project 'Ui.cs') (Join-Path $PSScriptRoot 'IntegrationTests.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Integration test compilation failed.' }
    [xml]$definition = Get-Content (Join-Path $project 'GrocerySystem.csproj')
    $namespaces = New-Object System.Xml.XmlNamespaceManager($definition.NameTable)
    $namespaces.AddNamespace('p', 'http://schemas.microsoft.com/developer/msbuild/2003')
    foreach ($hint in $definition.SelectNodes('//p:Reference/p:HintPath', $namespaces)) {
        Copy-Item (Join-Path $project $hint.InnerText) $output
    }
    [xml]$config = Get-Content (Join-Path $project 'App.config')
    $config.configuration.connectionStrings.add.connectionString = $ConnectionString
    $config.configuration.appSettings.add.value = [string]$CutoffHour
    $config.Save((Join-Path $output 'IntegrationTests.exe.config'))
    & (Join-Path $output 'IntegrationTests.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Integration checks failed. See the output above.' }
} finally { Remove-Item -Recurse -Force $output }
