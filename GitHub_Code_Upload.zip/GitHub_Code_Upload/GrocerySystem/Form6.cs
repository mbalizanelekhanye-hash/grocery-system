using System.Windows.Forms;
namespace GrocerySystem {
 public partial class FrmAbout : Form {
  public FrmAbout() { InitializeComponent(); }
  private void Build() {
   Ui.Form(this,"About Grocery System",800,510);
   Ui.Label(this,"Grocery Ordering and Management System",30,35,730);
   var text=Ui.Label(this,"A student-developed ICT3715 solution for an old-age home. Residents order groceries for Friday purchasing. The Matron maintains members and groceries, consolidates orders, and reviews ordering trends and participation.",30,100,725); text.Height=155;
   var rules=Ui.Label(this,"Orders allow up to 12 different items. Ordering closes on Thursday evening. Your selected quantities and captured prices are retained in the database. See README.md for the configured cut-off and setup.",30,270,725); rules.Height=100;
   Ui.Button(this,"Close",30,390,()=>Close());
  }
 }
}
