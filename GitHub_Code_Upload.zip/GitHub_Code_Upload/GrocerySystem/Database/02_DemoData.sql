-- OPTIONAL synthetic demonstration data. This is not the lecturer's dataset.
-- Run only in a demonstration database after 01_CreateSchema.sql.
USE groceryorderingdb_ict3715;
INSERT INTO Members(MemberID,FullName,RoomNumber,Phone,IsActive,PasswordHash) VALUES
(1,'Demo Resident One','A01','',1,'pbkdf2$100000$k+Vvl6p0qKa5txwfO+g5BQ==$FdnBx2IaQqxaEh9a3L3Q1Zn+chnCsYSWYYeniOeQ+4w='),
(2,'Demo Resident Two','A02','',1,'pbkdf2$100000$k+Vvl6p0qKa5txwfO+g5BQ==$FdnBx2IaQqxaEh9a3L3Q1Zn+chnCsYSWYYeniOeQ+4w='),
(3,'Demo Resident Three','A03','',1,'pbkdf2$100000$k+Vvl6p0qKa5txwfO+g5BQ==$FdnBx2IaQqxaEh9a3L3Q1Zn+chnCsYSWYYeniOeQ+4w=');
INSERT INTO grocery_items(ItemID,ItemName,Description,Price,IsAvailable,ImagePath) VALUES
(1,'Milk 1 litre','Fresh milk, 1 litre',19.99,1,''),
(2,'Brown bread','Brown bread loaf',18.50,1,''),
(3,'Eggs 6 pack','Six eggs',24.99,1,''),
(4,'Apples 1 kg','Fresh apples, one kilogram',29.99,1,''),
(5,'Bananas 1 kg','Fresh bananas, one kilogram',22.50,1,''),
(6,'Rice 1 kg','White rice, one kilogram',25.00,1,''),
(7,'Tea 40 bags','Forty tea bags',34.99,1,''),
(8,'Sugar 1 kg','White sugar, one kilogram',23.50,1,''),
(9,'Coffee 100 g','Instant coffee, one hundred grams',49.99,1,''),
(10,'Oats 500 g','Rolled oats, five hundred grams',28.00,1,''),
(11,'Soap','One bar of soap',12.00,1,''),
(12,'Toothpaste','One tube of toothpaste',21.00,1,''),
(13,'Biscuits','One packet of biscuits',17.00,1,''),
(14,'Unavailable demo item','Used to demonstrate availability filtering',10.00,0,'');
-- Four completed historical orders over three Friday cycles; captured prices
-- intentionally differ from today's prices to demonstrate history retention.
INSERT INTO Orders(OrderID,MemberID,WeekFriday,CreatedAt,UpdatedAt) VALUES
(1,1,'2026-09-04','2026-09-03 10:00:00','2026-09-03 10:00:00'),
(2,2,'2026-09-04','2026-09-03 11:00:00','2026-09-03 11:00:00'),
(3,1,'2026-09-11','2026-09-10 10:00:00','2026-09-10 10:00:00'),
(4,1,'2026-09-18','2026-09-17 10:00:00','2026-09-17 10:00:00');
INSERT INTO OrderItems(OrderID,ItemID,ItemNameSnapshot,Quantity,UnitPrice) VALUES
(1,1,'Milk 1 litre',2,18.00),(1,2,'Brown bread',1,17.00),
(2,1,'Milk 1 litre',1,18.00),(2,3,'Eggs 6 pack',2,24.00),
(3,1,'Milk 1 litre',3,19.00),(3,2,'Brown bread',2,18.00),
(4,1,'Milk 1 litre',1,19.00),(4,4,'Apples 1 kg',1,29.00);
