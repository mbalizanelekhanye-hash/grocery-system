namespace GrocerySystem { partial class FrmAbout { private void InitializeComponent() { Build(); } } }
