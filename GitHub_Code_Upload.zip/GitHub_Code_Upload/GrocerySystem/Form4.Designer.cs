namespace GrocerySystem { partial class FrmMembers { private void InitializeComponent() { Build(); } } }
