-- Run against MySQL 8.0.16+ or MariaDB 10.2.1+.
-- Uses a separate database to protect any earlier Phase 1 database.
-- Does not drop tables or existing records. If this name already holds a different
-- schema, choose another name here and in App.config.
CREATE DATABASE IF NOT EXISTS groceryorderingdb_ict3715 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE groceryorderingdb_ict3715;
CREATE TABLE IF NOT EXISTS Admins (
 AdminID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 Username VARCHAR(100) NOT NULL UNIQUE,
 PasswordHash VARCHAR(255) NOT NULL,
 IsActive BOOLEAN NOT NULL DEFAULT TRUE,
 CONSTRAINT CK_AdminActive CHECK (IsActive IN (0,1))
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Members (
 MemberID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 FullName VARCHAR(100) NOT NULL,
 RoomNumber VARCHAR(20) NOT NULL,
 Phone VARCHAR(30) NOT NULL DEFAULT '',
 IsActive BOOLEAN NOT NULL DEFAULT TRUE,
 PasswordHash VARCHAR(255) NOT NULL,
 CONSTRAINT CK_MemberActive CHECK (IsActive IN (0,1))
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS grocery_items (
 ItemID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 ItemName VARCHAR(100) NOT NULL UNIQUE,
 Description VARCHAR(500) NOT NULL,
 Price DECIMAL(10,2) NOT NULL,
 IsAvailable BOOLEAN NOT NULL DEFAULT TRUE,
 ImagePath VARCHAR(500) NOT NULL DEFAULT '',
 CONSTRAINT CK_ItemPrice CHECK (Price > 0),
 CONSTRAINT CK_ItemAvailable CHECK (IsAvailable IN (0,1))
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Orders (
 OrderID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 MemberID INT NOT NULL,
 WeekFriday DATE NOT NULL,
 CreatedAt DATETIME NOT NULL,
 UpdatedAt DATETIME NOT NULL,
 CONSTRAINT UQ_MemberWeek UNIQUE (MemberID,WeekFriday),
 CONSTRAINT FK_OrderMember FOREIGN KEY (MemberID) REFERENCES Members(MemberID) ON DELETE RESTRICT,
 CONSTRAINT CK_OrderFriday CHECK (DAYOFWEEK(WeekFriday)=6),
 INDEX IX_OrderFriday(WeekFriday)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS OrderItems (
 OrderID INT NOT NULL,
 ItemID INT NOT NULL,
 ItemNameSnapshot VARCHAR(100) NOT NULL,
 Quantity INT NOT NULL,
 UnitPrice DECIMAL(10,2) NOT NULL,
 PRIMARY KEY (OrderID,ItemID),
 CONSTRAINT FK_LineOrder FOREIGN KEY (OrderID) REFERENCES Orders(OrderID) ON DELETE RESTRICT,
 CONSTRAINT FK_LineItem FOREIGN KEY (ItemID) REFERENCES grocery_items(ItemID) ON DELETE RESTRICT,
 CONSTRAINT CK_LineQuantity CHECK (Quantity BETWEEN 1 AND 999),
 CONSTRAINT CK_LinePrice CHECK (UnitPrice > 0)
) ENGINE=InnoDB;
-- Bootstrap account for local demonstration; change it before operational use.
INSERT INTO Admins(Username,PasswordHash,IsActive)
SELECT 'matron','pbkdf2$100000$xQo+tvF/2hOmL4eW2IA0Ag==$6wnesq0Ea4T9AWzfcBDjJYRy64grj60tIJtIFKIOrys=',1 WHERE NOT EXISTS (SELECT 1 FROM Admins WHERE Username='matron');
