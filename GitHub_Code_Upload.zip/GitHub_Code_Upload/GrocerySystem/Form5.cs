using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
namespace GrocerySystem {
 public partial class FrmReports : Form {
  private ComboBox type; private DateTimePicker start,end; private DataGridView grid; private Label summary; private DataTable result;
  public FrmReports() { Session.RequireAdmin(); InitializeComponent(); }
  private void Build() {
   Ui.Form(this,"Matron - Reports and MIS",1200,810);
   Ui.Label(this,"Report",25,25,100);
   type=new ComboBox { Left=140,Top=25,Width=580,DropDownStyle=ComboBoxStyle.DropDownList }; Controls.Add(type);
   type.Items.AddRange(new object[]{"MIS 1 - Item ordering trends","MIS 2 - Member participation","Weekly purchasing list","Individual member order summaries","MIS 1 - Weekly item breakdown"}); type.SelectedIndex=0;
   Ui.Label(this,"Start / Friday",25,85,150); start=Ui.Date(this,180,85); start.Value=new DateTime(Rules.LocalNow.Year,1,1);
   Ui.Label(this,"End",385,85,70); end=Ui.Date(this,460,85); end.Value=Rules.LocalNow.Date;
   Ui.Button(this,"Generate",660,80,Generate);
   Ui.Button(this,"Export CSV",865,80,()=>Ui.Export(result,"GroceryReport"));
   grid=Ui.Grid(this,25,150,1130,430);
   summary=Ui.Label(this,"Choose a report and date range, then Generate.",25,610,1120); summary.Height=110;
   Ui.Button(this,"Close",970,720,()=>Close());
   Ui.Label(this,"Dates filter the Friday cycle. Participation = ordered Fridays / Fridays in the selected range.",25,735,915);
   start.ValueChanged+=(s,e)=>InvalidateReport(); end.ValueChanged+=(s,e)=>InvalidateReport(); type.SelectedIndexChanged+=(s,e)=>{end.Enabled=type.SelectedIndex!=2; InvalidateReport();};
  }
  private void InvalidateReport() { result=null; grid.DataSource=null; summary.Text="Filters changed. Generate the report again."; }
  private void Generate() {
   result=Db.Report(type.SelectedIndex,start.Value,end.Value); grid.DataSource=result;
   foreach(DataGridViewColumn c in grid.Columns) if(c.ValueType==typeof(decimal)) c.DefaultCellStyle.Format="N2";
   summary.Text=result.Rows.Count+" rows. Friday cycles: "+start.Value.ToString("dd MMM yyyy")+" to "+end.Value.ToString("dd MMM yyyy")+". ";
   if(type.SelectedIndex==0 && result.Rows.Count>0) {
    long highest=result.AsEnumerable().Max(r=>Convert.ToInt64(r["TotalQuantity"])); long lowest=result.AsEnumerable().Min(r=>Convert.ToInt64(r["TotalQuantity"]));
    summary.Text+="Most ordered quantity: "+highest+"; least ordered quantity: "+lowest+" (including items never ordered). Total captured value: "+Ui.Money(result.AsEnumerable().Sum(r=>Convert.ToDecimal(r["TotalValue"])));
   }
   if(type.SelectedIndex==1) summary.Text+="Possible weeks: "+Db.Fridays(start.Value,end.Value)+". Includes all retained members, including inactive and zero-order members. The rate uses the full selected range; it is not adjusted for joining/deactivation dates.";
   if(type.SelectedIndex==2) summary.Text=result.Rows.Count+" rows. Purchasing Friday: "+start.Value.ToString("dd MMM yyyy")+".";
   if(type.SelectedIndex==4) summary.Text+="One row per ordered item per Friday. Total captured value: "+Ui.Money(result.AsEnumerable().Sum(r=>Convert.ToDecimal(r["TotalValue"])));
   if(result.Rows.Count==0) summary.Text+=" No matching orders or items were found.";
  }
 }
}
