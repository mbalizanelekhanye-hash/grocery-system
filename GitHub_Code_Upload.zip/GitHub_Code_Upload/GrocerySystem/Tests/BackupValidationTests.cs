using System;
using System.Data;
using System.IO;
namespace GrocerySystem
{
    internal static class BackupValidationTests
    {
        public static void Run(Action<bool,string> assert)
        {
            var data=new DataSet("GroceryBackupV1");
            var admins=new DataTable("Admins"); admins.Columns.Add("AdminID",typeof(int));admins.Columns.Add("Username");admins.Columns.Add("PasswordHash");admins.Columns.Add("IsActive",typeof(bool));
            admins.Rows.Add(1,"test",Passwords.Hash("Test1234"),true);data.Tables.Add(admins);
            var members=new DataTable("Members");members.Columns.Add("MemberID",typeof(int));members.Columns.Add("FullName");members.Columns.Add("RoomNumber");members.Columns.Add("Phone");members.Columns.Add("IsActive",typeof(bool));members.Columns.Add("PasswordHash");
            members.Rows.Add(1,"Test Resident","A1","",true,Passwords.Hash("Test1234"));data.Tables.Add(members);
            var items=new DataTable("grocery_items");items.Columns.Add("ItemID",typeof(int));items.Columns.Add("ItemName");items.Columns.Add("Description");items.Columns.Add("Price",typeof(decimal));items.Columns.Add("IsAvailable",typeof(bool));items.Columns.Add("ImagePath");
            items.Rows.Add(1,"Test item","Test description",9.99m,true,"");data.Tables.Add(items);
            var orders=new DataTable("Orders");orders.Columns.Add("OrderID",typeof(int));orders.Columns.Add("MemberID",typeof(int));orders.Columns.Add("WeekFriday",typeof(DateTime));orders.Columns.Add("CreatedAt",typeof(DateTime));orders.Columns.Add("UpdatedAt",typeof(DateTime));
            orders.Rows.Add(1,1,new DateTime(2026,9,4),new DateTime(2026,9,3,10,0,0),new DateTime(2026,9,3,10,0,0));data.Tables.Add(orders);
            var lines=new DataTable("OrderItems");lines.Columns.Add("OrderID",typeof(int));lines.Columns.Add("ItemID",typeof(int));lines.Columns.Add("ItemNameSnapshot");lines.Columns.Add("Quantity",typeof(int));lines.Columns.Add("UnitPrice",typeof(decimal));
            lines.Rows.Add(1,1,"Test item",2,9.99m);data.Tables.Add(lines);
            Backup.Validate(data);assert(true,"Valid related backup passes integrity checks");
            string path=Path.Combine(Path.GetTempPath(),"GroceryBackupValidation_"+Guid.NewGuid().ToString("N")+".xml");
            try { data.WriteXml(path,XmlWriteMode.WriteSchema);var read=Backup.Read(path);assert(Convert.ToDecimal(read.Tables["OrderItems"].Rows[0]["UnitPrice"])==9.99m,"Backup XML round trip preserves decimal price"); }
            finally {if(File.Exists(path))File.Delete(path);}
            lines.Rows[0]["Quantity"]=0;Reject(data,assert,"Invalid backup quantity rejected");lines.Rows[0]["Quantity"]=2;
            orders.Rows[0]["MemberID"]=999;Reject(data,assert,"Orphaned backup member reference rejected");orders.Rows[0]["MemberID"]=1;
            orders.Rows[0]["WeekFriday"]=new DateTime(2026,9,5);Reject(data,assert,"Non-Friday backup order rejected");orders.Rows[0]["WeekFriday"]=new DateTime(2026,9,4);
            admins.Rows[0]["IsActive"]=false;Reject(data,assert,"Backup without active Matron rejected");
        }
        private static void Reject(DataSet data,Action<bool,string> assert,string label)
        {try{Backup.Validate(data);}catch(InvalidOperationException){assert(true,label);return;}throw new Exception("FAILED: "+label);}
    }
}
