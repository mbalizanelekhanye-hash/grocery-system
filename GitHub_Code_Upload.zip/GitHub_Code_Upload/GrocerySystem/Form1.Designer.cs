namespace GrocerySystem { partial class FrmDashboard { private void InitializeComponent() { Build(); } } }
