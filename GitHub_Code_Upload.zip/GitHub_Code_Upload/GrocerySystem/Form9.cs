using System;
using System.Data;
using System.Windows.Forms;
namespace GrocerySystem {
 public partial class FrmViewOrders : Form {
  private DataGridView orders,details; private DataTable detail; private Label total;
  public FrmViewOrders() { Session.RequireMember(); InitializeComponent(); Shown+=(s,e)=>Ui.Run(LoadOrders); }
  private void Build() {
   Ui.Form(this,"My saved orders",1100,800);
   Ui.Label(this,"Select an order to view its captured quantities and prices.",25,20,1020);
   orders=Ui.Grid(this,25,65,1025,260); orders.SelectionChanged+=(s,e)=>Ui.Run(LoadDetails);
   details=Ui.Grid(this,25,350,1025,260); total=Ui.Label(this,"",25,640,1020);
   Ui.Button(this,"Refresh",25,695,LoadOrders);
   Ui.Button(this,"Export summary",230,695,()=>Ui.Export(detail,"MyOrder"),220);
   Ui.Button(this,"Close",480,695,()=>Close());
  }
  private void LoadOrders() { orders.DataSource=Db.MyOrders(); if(orders.Columns.Contains("Total"))orders.Columns["Total"].DefaultCellStyle.Format="N2"; if(orders.Rows.Count==0){detail=null;details.DataSource=null;total.Text="You have no saved orders.";} }
  private void LoadDetails() { if(orders.CurrentRow==null)return; detail=Db.MyDetails(Convert.ToInt32(Ui.Cell(orders,"OrderID")));details.DataSource=detail;foreach(string c in new[]{"UnitPrice","LineTotal"})details.Columns[c].DefaultCellStyle.Format="N2";decimal sum=0;foreach(DataRow r in detail.Rows)sum+=Convert.ToDecimal(r["LineTotal"]);total.Text="Order "+Ui.Cell(orders,"OrderID")+" for "+Convert.ToDateTime(orders.CurrentRow.Cells["WeekFriday"].Value).ToString("dd MMM yyyy")+". Total: "+Ui.Money(sum); }
 }
}
