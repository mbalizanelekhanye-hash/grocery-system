$ErrorActionPreference = 'Stop'
$project = Split-Path $PSScriptRoot -Parent
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path $compiler)) { $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
if (!(Test-Path $compiler)) { throw 'Install .NET Framework 4.7.2 or later first.' }
$output = Join-Path $env:TEMP ('GroceryRuleTests_' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $output | Out-Null
try {
    $mysql = Join-Path $project 'packages\MySql.Data.26.7.0\lib\net462\MySql.Data.dll'
    & $compiler /nologo /target:exe ("/out:" + (Join-Path $output 'RuleTests.exe')) /r:System.Data.dll /r:System.Data.DataSetExtensions.dll /r:System.Core.dll /r:System.Configuration.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll ("/r:" + $mysql) (Join-Path $project 'Core.cs') (Join-Path $project 'Backup.cs') (Join-Path $project 'Ui.cs') (Join-Path $PSScriptRoot 'RuleTests.cs') (Join-Path $PSScriptRoot 'BackupValidationTests.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed.' }
    Copy-Item $mysql $output
    Copy-Item (Join-Path $project 'App.config') (Join-Path $output 'RuleTests.exe.config')
    & (Join-Path $output 'RuleTests.exe')
    if ($LASTEXITCODE -ne 0) { throw 'Rule tests failed.' }
} finally { Remove-Item -Recurse -Force $output }
