namespace GrocerySystem { partial class FrmReports { private void InitializeComponent() { Build(); } } }
