using System;
using System.Collections.Generic;
using System.Linq;
namespace GrocerySystem
{
    internal static class RuleTests
    {
        private static int count;
        private static void Assert(bool condition,string label) { if(!condition)throw new Exception("FAILED: "+label); count++; Console.WriteLine("PASS: "+label); }
        private static void Reject(Action action,string label) { try{action();}catch(InvalidOperationException){Assert(true,label);return;}throw new Exception("FAILED: "+label); }
        public static void Main()
        {
            var thursday=new DateTime(2026,10,8,19,59,59); var friday=new DateTime(2026,10,9);
            Assert(Rules.Friday(thursday)==friday,"Thursday targets the next Friday");
            Assert(Rules.Friday(friday)==friday,"Friday stays in its closed cycle");
            Assert(Rules.Friday(friday.AddDays(1))==friday.AddDays(7),"Saturday opens the next Friday cycle");
            Rules.CheckWindow(friday,thursday); Assert(true,"One second before cut-off is permitted");
            Reject(()=>Rules.CheckWindow(friday,new DateTime(2026,10,8,20,0,0)),"Exact cut-off is closed");
            Reject(()=>Rules.CheckWindow(friday,friday.AddHours(8)),"Friday ordering is closed");
            Reject(()=>Rules.CheckWindow(friday.AddDays(7),thursday),"Future week cannot bypass the cycle");
            Assert(Db.Fridays(new DateTime(2026,9,4),new DateTime(2026,9,18))==3,"Participation counts three inclusive Fridays");
            Assert(Db.Fridays(new DateTime(2026,9,5),new DateTime(2026,9,10))==0,"Range without Fridays has zero opportunities");
            var cart=Enumerable.Range(1,12).Select(i=>new CartLine{ItemId=i,Quantity=1,UnitPrice=1.23m}).ToList();
            Rules.CheckCart(cart);Assert(true,"Twelve different items accepted");
            Assert(cart.Sum(x=>x.LineTotal)==14.76m,"Decimal order total is exact");
            cart.Add(new CartLine{ItemId=13,Quantity=1}); Reject(()=>Rules.CheckCart(cart),"Thirteenth item rejected");
            cart.RemoveAt(12);cart[1].ItemId=1;Reject(()=>Rules.CheckCart(cart),"Duplicate item rejected");
            cart[1].ItemId=2;cart[0].Quantity=0;Reject(()=>Rules.CheckCart(cart),"Zero quantity rejected");
            cart[0].Quantity=1000;Reject(()=>Rules.CheckCart(cart),"Excessive quantity rejected");
            Reject(()=>Rules.CheckCart(new List<CartLine>()),"Empty order rejected");
            string hash=Passwords.Hash("Member2026"); Assert(Passwords.Verify("Member2026",hash),"Correct password verified");
            Assert(!Passwords.Verify("WrongPassword",hash),"Wrong password rejected");
            Assert(!Passwords.Verify("password","malformed"),"Malformed credential rejected");
            Assert(Passwords.Hash("Member2026")!=hash,"Random salts produce different hashes");
            Session.Clear(); Reject(Session.RequireAdmin,"Unauthenticated maintenance denied");
            Reject(Session.RequireMember,"Unauthenticated member access denied");
            Session.Member(1,"Demo");Reject(Session.RequireAdmin,"Member cannot access Matron services");
            Session.Admin("matron");Reject(Session.RequireMember,"Matron cannot impersonate a member");
            Session.Clear();BackupValidationTests.Run(Assert);Console.WriteLine(count+" checks passed.");
        }
    }
}
