namespace GrocerySystem { partial class Login { private void InitializeComponent() { Build(); } } }
