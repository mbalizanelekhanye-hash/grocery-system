USE groceryorderingdb_ict3715;
-- Demonstrate where an order is stored and verify captured historical values.
SELECT o.OrderID,m.MemberID,m.FullName,o.WeekFriday,o.CreatedAt,
 d.ItemID,d.ItemNameSnapshot,d.Quantity,d.UnitPrice,d.Quantity*d.UnitPrice AS LineTotal
FROM Orders o JOIN Members m ON m.MemberID=o.MemberID
JOIN OrderItems d ON d.OrderID=o.OrderID ORDER BY o.OrderID,d.ItemID;
-- These checks must return zero rows.
SELECT MemberID,WeekFriday,COUNT(*) FROM Orders GROUP BY MemberID,WeekFriday HAVING COUNT(*)>1;
SELECT OrderID FROM Orders WHERE DAYOFWEEK(WeekFriday)<>6;
SELECT OrderID,COUNT(*) FROM OrderItems GROUP BY OrderID HAVING COUNT(*)>12;
SELECT * FROM OrderItems WHERE Quantity NOT BETWEEN 1 AND 999 OR UnitPrice<=0;
SELECT o.OrderID FROM Orders o LEFT JOIN OrderItems d ON d.OrderID=o.OrderID WHERE d.OrderID IS NULL;
-- Expected demo values: Milk quantity=7/value=130; Bread quantity=3/value=53;
-- Eggs quantity=2/value=48; Apples quantity=1/value=29; grand total=260.
SELECT d.ItemID,SUM(d.Quantity) AS Quantity,SUM(d.Quantity*d.UnitPrice) AS Value
FROM Orders o JOIN OrderItems d ON d.OrderID=o.OrderID
WHERE o.WeekFriday BETWEEN '2026-09-04' AND '2026-09-18' GROUP BY d.ItemID;
-- Expected: member 1=3/3 (100%), member 2=1/3 (33.33%), member 3=0/3 (0%).
SELECT m.MemberID,m.FullName,COUNT(o.OrderID) AS WeeksOrdered,
 ROUND(COUNT(o.OrderID)*100.0/3,2) AS ParticipationPercent
FROM Members m LEFT JOIN Orders o ON o.MemberID=m.MemberID
 AND o.WeekFriday BETWEEN '2026-09-04' AND '2026-09-18'
GROUP BY m.MemberID,m.FullName ORDER BY m.MemberID;
