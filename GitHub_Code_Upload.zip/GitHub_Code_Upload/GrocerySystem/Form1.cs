using System;
using System.Windows.Forms;
namespace GrocerySystem {
 public partial class FrmDashboard : Form {
  public FrmDashboard() { Session.RequireAdmin(); InitializeComponent(); }
  private void Build() {
   Ui.Form(this,"Matron dashboard",900,600);
   Ui.Label(this,"Grocery Ordering and Management",35,35,750);
   Ui.Label(this,"Welcome, "+Session.Name+". Choose a task below.",35,85,750);
   Ui.Button(this,"Members",35,150,()=>{ using(var f=new FrmMembers()) f.ShowDialog(this); },350);
   Ui.Button(this,"Grocery items",430,150,()=>{ using(var f=new FrmGroceryItems()) f.ShowDialog(this); },350);
   Ui.Button(this,"Reports / MIS",35,220,()=>{ using(var f=new FrmReports()) f.ShowDialog(this); },350);
   Ui.Button(this,"Backup / recovery",430,220,()=>{ using(var f=new BackupForm()) f.ShowDialog(this); if(!Session.IsAdmin) Close(); },350);
   Ui.Button(this,"About",35,310,()=>{ using(var f=new FrmAbout()) f.ShowDialog(this); },350);
   Ui.Button(this,"Log out",430,310,()=>Close(),350);
   Ui.Button(this,"Change my password",35,390,()=>{using(var f=new PasswordForm()) f.ShowDialog(this);},350);
  }
 }
}
