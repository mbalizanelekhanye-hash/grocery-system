using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
namespace GrocerySystem {
 public partial class FrmOderlist : Form {
  private DataGridView catalogue,basket; private TextBox search; private NumericUpDown quantity; private Label total,status; private PictureBox preview;
  private Button add,remove,save; private List<CartLine> cart=new List<CartLine>(); private DataTable items; private DateTime friday; private Timer clock;
  public FrmOderlist() { Session.RequireMember(); InitializeComponent(); Shown+=(s,e)=>Ui.Run(LoadData); }
  private void Build() {
   Ui.Form(this,"My weekly grocery order",1250,890);
   friday=Rules.Friday(Rules.LocalNow); status=Ui.Label(this,"",25,20,1190); status.Height=65;
   Ui.Label(this,"Find an item",25,90,150); search=Ui.Text(this,185,90,480); search.MaxLength=100; search.TextChanged+=(s,e)=>Filter();
   Ui.Button(this,"Refresh catalogue",820,85,LoadCatalogue,350);
   catalogue=Ui.Grid(this,25,145,880,250); catalogue.CurrentCellChanged+=(s,e)=>Ui.Run(UpdateSelectedItem);
   preview=new PictureBox { Left=930,Top=145,Width=240,Height=250,SizeMode=PictureBoxSizeMode.Zoom,BorderStyle=BorderStyle.FixedSingle }; Controls.Add(preview);
   Ui.Label(this,"Quantity",25,415,150); quantity=new NumericUpDown { Left=185,Top=415,Width=130,Minimum=1,Maximum=999,Value=1 }; Controls.Add(quantity);
   add=Ui.Button(this,"Add / set quantity",355,410,Add,290);
   remove=Ui.Button(this,"Remove selected",675,410,Remove,290);
   basket=Ui.Grid(this,25,475,1145,230);
   total=Ui.Label(this,"",25,730,650);
   save=Ui.Button(this,"Save weekly order",25,780,Save,340);
   Ui.Button(this,"Close",400,780,()=>Close(),200);
   clock=new Timer { Interval=1000 }; clock.Tick+=(s,e)=>UpdateWindow(); clock.Start();
   FormClosed+=(s,e)=>{clock.Dispose(); if(preview.Image!=null)preview.Image.Dispose();};
  }
  private void LoadData() { LoadCatalogue(); cart=Db.LoadOrder(friday); RefreshBasket(); UpdateSelectedItem(); UpdateWindow(); }
  private void LoadCatalogue() { items=Db.Items(true); catalogue.DataSource=items; foreach(string col in new[]{"ItemID","IsAvailable","ImagePath"}) if(catalogue.Columns.Contains(col)) catalogue.Columns[col].Visible=false; Filter(); }
  private void Filter() { if(items==null)return; string term=search.Text.Trim(); items.DefaultView.RowFilter=""; if(term.Length>0) {
   // LINQ filtering avoids interpreting search characters as expression syntax.
   var rows=items.AsEnumerable().Where(r=>Convert.ToString(r["ItemName"]).IndexOf(term,StringComparison.OrdinalIgnoreCase)>=0 || Convert.ToString(r["Description"]).IndexOf(term,StringComparison.OrdinalIgnoreCase)>=0).ToList();
   catalogue.DataSource=rows.Count>0 ? rows.CopyToDataTable() : items.Clone();
  } else catalogue.DataSource=items;
   foreach(string col in new[]{"ItemID","IsAvailable","ImagePath"}) if(catalogue.Columns.Contains(col)) catalogue.Columns[col].Visible=false;
  }
  private void Add() {
   Rules.CheckWindow(friday,Rules.LocalNow); int id=Convert.ToInt32(Ui.Cell(catalogue,"ItemID")); var line=cart.FirstOrDefault(x=>x.ItemId==id);
   if(line==null) { if(cart.Count>=12)throw new InvalidOperationException("You may choose no more than 12 different items. Remove an item first.");
    line=new CartLine { ItemId=id,ItemName=Ui.Cell(catalogue,"ItemName"),UnitPrice=Convert.ToDecimal(catalogue.CurrentRow.Cells["Price"].Value) }; cart.Add(line);
   }
   line.Quantity=(int)quantity.Value; RefreshBasket();
  }
  private void Remove() { Rules.CheckWindow(friday,Rules.LocalNow); int id=Convert.ToInt32(Ui.Cell(basket,"ItemId")); cart.RemoveAll(x=>x.ItemId==id); RefreshBasket(); UpdateSelectedItem(); }
  private void RefreshBasket() { basket.DataSource=null; basket.DataSource=cart.ToList(); if(basket.Columns.Contains("ItemId"))basket.Columns["ItemId"].Visible=false; foreach(string col in new[]{"UnitPrice","LineTotal"})if(basket.Columns.Contains(col))basket.Columns[col].DefaultCellStyle.Format="N2"; total.Text=cart.Count+" / 12 different items. Total: "+Ui.Money(cart.Sum(x=>x.LineTotal)); }
  private void Save() {
   long orderId=Db.SaveOrder(friday,cart);
   Ui.Info("Order #"+orderId+" for Friday "+friday.ToString("dd MMM yyyy")+" has been saved. You can change it before the cut-off.");
   cart=Db.LoadOrder(friday); RefreshBasket(); UpdateSelectedItem();
  }
  private void UpdateSelectedItem() {
   var row=catalogue.CurrentRow?.DataBoundItem as DataRowView;
   var line=row==null ? null : cart.FirstOrDefault(x=>x.ItemId==Convert.ToInt32(row["ItemID"]));
   quantity.Value=line==null ? 1 : line.Quantity;
   ShowImage();
  }
  private void UpdateWindow() {
   DateTime now=Rules.LocalNow; bool open=Rules.Friday(now)==friday && now<Rules.Cutoff(friday);
   add.Enabled=remove.Enabled=save.Enabled=open;
   status.Text="Purchasing Friday: "+friday.ToString("dd MMM yyyy")+". Cut-off: "+Rules.Cutoff(friday).ToString("dddd dd MMM HH:mm")+" (South African time).\n"+(open ? "Choose up to 12 different items. Select an item and set its quantity, then Save." : "Ordering is closed. Existing orders are read-only. Reopen this screen for the next cycle on Saturday.");
  }
  private void ShowImage() {
   if(preview.Image!=null){preview.Image.Dispose();preview.Image=null;} if(catalogue.CurrentRow==null)return;
   string image=Ui.Cell(catalogue,"ImagePath"); string path=Path.IsPathRooted(image)?image:Path.Combine(AppDomain.CurrentDomain.BaseDirectory,image);
   if(File.Exists(path))using(var source=Image.FromFile(path))preview.Image=new Bitmap(source);
  }
 }
}
