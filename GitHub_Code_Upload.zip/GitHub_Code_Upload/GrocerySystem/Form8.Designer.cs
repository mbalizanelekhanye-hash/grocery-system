namespace GrocerySystem { partial class FrmOderlist { private void InitializeComponent() { Build(); } } }
