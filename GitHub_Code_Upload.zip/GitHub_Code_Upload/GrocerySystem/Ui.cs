using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GrocerySystem
{
    internal sealed class PasswordForm : Form
    {
        private TextBox current,next,confirmation;
        public PasswordForm()
        {
            Session.RequireAdmin(); Ui.Form(this,"Change Matron password",750,450);
            Ui.Label(this,"Current password",25,40); current=Ui.Text(this,300,40,350,true);
            Ui.Label(this,"New password",25,110); next=Ui.Text(this,300,110,350,true);
            Ui.Label(this,"Confirm password",25,180); confirmation=Ui.Text(this,300,180,350,true);
            current.MaxLength=next.MaxLength=confirmation.MaxLength=128;
            Ui.Button(this,"Save password",300,260,()=>{
                if(next.Text!=confirmation.Text) throw new InvalidOperationException("The new passwords do not match.");
                Db.ChangeAdminPassword(current.Text,next.Text); Ui.Info("Your Matron password has been changed."); Close();
            },350);
            Ui.Button(this,"Cancel",25,260,()=>Close());
        }
    }
    internal static class Ui
    {
        public static void Form(Form form, string title, int width=1100, int height=740)
        {
            Rectangle workArea=Screen.FromPoint(Cursor.Position).WorkingArea;
            form.Text=title;
            form.Size=new Size(Math.Min(width,workArea.Width),Math.Min(height,workArea.Height));
            form.AutoScroll=true;
            form.StartPosition=FormStartPosition.CenterScreen; form.Font=new Font("Segoe UI",12);
            form.BackColor=Color.FromArgb(245,248,247); form.AutoScaleMode=AutoScaleMode.Dpi;
        }
        public static Label Label(Control parent, string text, int x, int y, int width=250)
        { var c=new Label { Text=text,Location=new Point(x,y),Size=new Size(width,32) }; parent.Controls.Add(c); return c; }
        public static TextBox Text(Control parent, int x, int y, int width=280, bool password=false)
        { var c=new TextBox { Location=new Point(x,y),Width=width,UseSystemPasswordChar=password }; parent.Controls.Add(c); return c; }
        public static Button Button(Control parent, string text, int x, int y, Action action, int width=180)
        {
            var c=new Button { Text=text,Location=new Point(x,y),Size=new Size(width,44),BackColor=Color.FromArgb(22,100,81),ForeColor=Color.White,FlatStyle=FlatStyle.Flat };
            c.Click+=(s,e)=>Run(action); parent.Controls.Add(c); return c;
        }
        public static DataGridView Grid(Control parent, int x, int y, int width, int height)
        {
            var c=new DataGridView { Location=new Point(x,y),Size=new Size(width,height),ReadOnly=true,AllowUserToAddRows=false,AllowUserToDeleteRows=false,MultiSelect=false,SelectionMode=DataGridViewSelectionMode.FullRowSelect,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,RowHeadersVisible=false,BackgroundColor=Color.White,AutoGenerateColumns=true,AutoSizeRowsMode=DataGridViewAutoSizeRowsMode.AllCells };
            c.DefaultCellStyle.WrapMode=DataGridViewTriState.True;
            parent.Controls.Add(c); return c;
        }
        public static CheckBox Check(Control parent, string text, int x, int y)
        { var c=new CheckBox { Text=text,Location=new Point(x,y),Size=new Size(290,32),Checked=true }; parent.Controls.Add(c); return c; }
        public static DateTimePicker Date(Control parent, int x, int y)
        { var c=new DateTimePicker { Location=new Point(x,y),Width=160,Format=DateTimePickerFormat.Custom,CustomFormat="dd MMM yyyy" }; parent.Controls.Add(c); return c; }
        public static void Run(Action action)
        {
            try { action(); }
            catch (MySqlException e)
            {
                string message=e.Number==1062 ? "This record already exists. Choose another name or edit the existing record." :
                    e.Number==1045 ? "Database login failed. Check the database username and password in App.config." :
                    e.Number==1049 || e.Number==1146 || e.Number==1054 ? "Database setup does not match this application. Follow README.md and use the supplied schema in a separate database before importing existing data." :
                    e.Number==1213 || e.Number==1205 ? "Another user is updating these records. Please try again." :
                    "The database could not complete the operation. Check that MySQL is running and that App.config contains the correct connection details. Details: " + e.Message;
                MessageBox.Show(message,"Database",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            catch (Exception e) { MessageBox.Show(e.Message,"Please check",MessageBoxButtons.OK,MessageBoxIcon.Warning); }
        }
        public static void Info(string message) { MessageBox.Show(message,"Grocery System",MessageBoxButtons.OK,MessageBoxIcon.Information); }
        public static string Money(decimal amount) { return amount.ToString("C2",CultureInfo.GetCultureInfo("en-ZA")); }
        public static string Cell(DataGridView grid, string name)
        { if (grid.CurrentRow==null) throw new InvalidOperationException("Select a row first."); return Convert.ToString(grid.CurrentRow.Cells[name].Value); }
        public static void Export(DataTable table, string title)
        {
            if (table==null || table.Rows.Count==0) throw new InvalidOperationException("There are no rows to export. Generate or select a report first.");
            using (var dialog=new SaveFileDialog { Filter="CSV file (*.csv)|*.csv",FileName=title+".csv" })
            {
                if (dialog.ShowDialog()!=DialogResult.OK) return;
                Func<object,string> quote=value=>
                {
                    string text=value is DateTime ? ((DateTime)value).ToString("yyyy-MM-dd HH:mm:ss") : Convert.ToString(value,CultureInfo.InvariantCulture);
                    // Prevent spreadsheet formula execution when exported text begins with a formula marker.
                    if (value is string && text.Length>0 && "=+-@\t\r".Contains(text[0])) text="'"+text;
                    return "\""+text.Replace("\"","\"\"")+"\"";
                };
                using (var writer=new StreamWriter(dialog.FileName,false,new UTF8Encoding(true)))
                {
                    writer.WriteLine(string.Join(",",table.Columns.Cast<DataColumn>().Select(c=>quote(c.ColumnName))));
                    foreach (DataRow row in table.Rows) writer.WriteLine(string.Join(",",row.ItemArray.Select(quote)));
                }
                Info("Report saved to " + dialog.FileName);
            }
        }
    }
}
