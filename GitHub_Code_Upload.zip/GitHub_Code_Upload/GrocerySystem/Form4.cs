using System;
using System.Windows.Forms;
namespace GrocerySystem {
 public partial class FrmMembers : Form {
  private DataGridView grid; private TextBox name,room,phone,password; private CheckBox active; private int id;
  public FrmMembers() { Session.RequireAdmin(); InitializeComponent(); Shown+=(s,e)=>Ui.Run(LoadMembers); }
  private void Build() {
   Ui.Form(this,"Member maintenance",1050,800);
   Ui.Label(this,"Select a member to edit, or choose New member.",25,20,980);
   grid=Ui.Grid(this,25,65,980,270); grid.SelectionChanged+=(s,e)=>Ui.Run(SelectMember);
   Ui.Label(this,"Full name",25,365); name=Ui.Text(this,300,365,480); name.MaxLength=100;
   Ui.Label(this,"Room number",25,415); room=Ui.Text(this,300,415,230); room.MaxLength=20;
   Ui.Label(this,"Phone (optional)",25,465); phone=Ui.Text(this,300,465,230); phone.MaxLength=30;
   Ui.Label(this,"New password",25,515); password=Ui.Text(this,300,515,230,true); password.MaxLength=128;
   active=Ui.Check(this,"Active member",620,415);
   Ui.Label(this,"Leave password blank to keep it when editing. New members need a password.",25,565,980);
   Ui.Button(this,"New member",25,620,Clear);
   Ui.Button(this,"Save member",230,620,Save);
   Ui.Button(this,"Refresh",435,620,LoadMembers);
   Ui.Button(this,"Close",640,620,()=>Close());
  }
  private void LoadMembers() { grid.DataSource=Db.Members(); }
  private void Clear() { id=0; name.Clear(); room.Clear(); phone.Clear(); password.Clear(); active.Checked=true; name.Focus(); }
  private void SelectMember() { if(grid.CurrentRow==null)return; id=Convert.ToInt32(Ui.Cell(grid,"MemberID")); name.Text=Ui.Cell(grid,"FullName"); room.Text=Ui.Cell(grid,"RoomNumber"); phone.Text=Ui.Cell(grid,"Phone"); active.Checked=Convert.ToBoolean(grid.CurrentRow.Cells["IsActive"].Value); password.Clear(); }
  private void Save() { int saved=Db.SaveMember(id,name.Text,room.Text,phone.Text.Trim(),active.Checked,password.Text); LoadMembers(); Clear(); Ui.Info("Member saved. Member ID: "+saved); }
 }
}
